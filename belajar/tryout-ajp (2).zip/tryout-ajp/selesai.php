<?php
include("index.php"); //menghubungkan dangan file fungsi php
?>
<!DOCTYPE html>
<html>

<head>
        <title>Data Pembelian Sparepart Motor</title>
        <link rel="stylesheet" type="text/css " href=".assets/css/bootstrap.css"> <!-- menghubungkan halaman web ke file library css -->

</head>

<body>
        <div class="container border">

                <!-- Menampilkan judul halaman -->
                <h3>Data Pembelian Sparepart Motor</h3>
                <img src="./assets/gambar/logo2.png" alt>
                <?php
                if (isset($_GET["hitung"])) {
                        $data_json = file_get_contents($file_path);
                        $data_array = json_decode($data_json, true);

                        $nama_konsumen = $_POST['nama_konsumen'];
                        $jml_beli = $_POST['jumlah'];

                        //mendapatkan kode, nama, harga dari sparepart
                        foreach ($sparepart as $item) {
                                if ($item['kode'] === $_POST['sparepart']) {
                                        $kode_alat = $item['kode'];
                                        $nama_alat = $item['nama_sprt'];
                                        $harga_alat = $item['harga_sprt'];
                                        break;
                                }
                        }

                        //menyimpan semua data pembelian
                        $data_pembelian = array(
                                "nama_konsumen" => $nama_konsumen,
                                "kode_alat" => $kode_alat,
                                "nama_alat" => $nama_alat,
                                "harga_alat" => $harga_alat,
                                "jml_beli" => $jml_beli
                        );
                        //menampilkan data pembelian
                        echo "Data Pembelian: <br>";
                        echo "Nama Konsumen:" . $data_pembelian['nama_konsumen'] . "<br>";
                        echo "Kode Alat:" . $data_pembelian['kode_alat'] . "<br>";
                        echo "Nama Alat:" . $data_pembelian['nama_alat'] . "<br>";
                        echo "Harga Beli: Rp." . $data_pembelian['harga_alat'] . "<br>";
                        echo "Jumlah Dibeli:" . $data_pembelian['jml_beli'] . "<br>";
                }
                ?>
        </div>
</body>

</html>